# Simulador de circuito pneumático

Bancada virtual para montar e testar circuitos pneumáticos básicos direto no navegador.
Sem instalação, sem dependências: um arquivo HTML.

## O que dá para fazer

- Colocar na bancada unidade de conservação, válvula 3/2 NF, válvula 5/2, cilindro de simples ação e cilindro de dupla ação.
- Ligar mangueiras clicando em duas portas (1, 2, 3, 4, 5).
- Acionar as válvulas e ver a linha pressurizada mudar de cor.
- Ver o cilindro avançar e recuar conforme a pressão chega nas câmaras.

## Como funciona por dentro

O circuito é tratado como um **grafo de portas**:

1. Cada componente declara suas portas e quais delas ficam interligadas em cada posição
   da válvula (`caminhos(estado)`).
2. Cada mangueira é uma aresta entre duas portas de componentes diferentes.
3. A partir da porta 1 da unidade de conservação, um *flood fill* marca todas as portas
   que recebem ar.
4. Os atuadores olham para as próprias portas: dupla ação avança quando só a porta 1
   está pressurizada e recua quando só a porta 2 está; simples ação retorna por mola.

É a mesma lógica de um simulador comercial, só que enxuta o suficiente para caber
em um arquivo e ser lida de cabo a rabo.

## Como usar

Abra o `index.html` no navegador. Ou publique no GitHub Pages:

```
Settings → Pages → Branch: main → / (root)
```

## Roteiro de testes

| Circuito | Montagem | Resultado esperado |
|---|---|---|
| Comando direto | compressor → 3/2 (1) · 3/2 (2) → cilindro simples (1) | avança enquanto o botão está acionado |
| Comando indireto | compressor → 5/2 (1) · 5/2 (2) → cilindro duplo (1) · 5/2 (4) → cilindro duplo (2) | a válvula guarda a posição (memória) |
| Sem alimentação | cilindro ligado só na válvula | nenhuma porta fica azul |

## Próximos passos

- [ ] Válvula 5/3 com centro fechado
- [ ] Regulador de vazão unidirecional (controle de velocidade)
- [ ] Sensores fim de curso e sequência automática
- [ ] Salvar e carregar o circuito em JSON

---

Feito por: Thiagosystems
