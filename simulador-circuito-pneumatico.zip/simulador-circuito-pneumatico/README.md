# Simulador de circuito pneumático

Bancada virtual para montar e testar circuitos pneumáticos básicos direto no navegador.
Sem instalação, sem dependências: um arquivo HTML.

## O que dá para fazer

- Montar o circuito com o catálogo completo, organizado por categoria na lateral:
  - **Elementos de alimentação** — compressor, unidade de conservação (FRL), reservatório, fonte de vácuo, filtro de ar, separador de água.
  - **Atuadores** — cilindro simples ação, dupla ação, dupla ação amortecido, haste passante, motor pneumático, atuador giratório, ventosa e garra pneumática.
  - **Válvulas de vias** — 2/2, 3/2, 3/3, 4/2, 4/3, 5/2 e 5/3, todas com o mesmo desenho genérico de quadros e a mesma forma de acionar.
  - **Mecanismos de acionamento** — botão simples, cogumelo, com trava, alavanca, pedal, rolete, rolete escamoteável, mola, piloto pneumático e solenoide. Escolha um na lista e clique na engrenagem (⚙) de uma válvula na bancada para aplicá-lo.
  - **Bloqueio, fluxo e pressão** — antirretorno, antirretorno pilotada, alternadora (OU), simultaneidade (E), escape rápido, reguladoras de fluxo bi/unidirecional, reguladora de pressão, limitadora de pressão, sequência e pressostato.
  - **Instrumentos e linhas** — manômetro, medidor de fluxo, indicador óptico, silenciador, ponto de exaustão e distribuidor de ar.
- Ligar mangueiras **arrastando** de uma porta até outra, como no FluidSIM: clique e segure numa porta, arraste até o alvo (ele fica destacado em vermelho quando está a distância de solda) e solte. Soltar fora de uma porta cancela a ligação.
- Escolher no rodapé se a próxima mangueira é uma **linha de pressão** (traço sólido) ou **linha de piloto/controle** (traço tracejado).
- Acionar válvulas e ver a linha pressurizada mudar de cor; cilindros, motores, atuadores giratórios e garras se movem em tempo real conforme a pressão chega.

## Como funciona por dentro

O circuito é tratado como um **grafo dirigido de portas**:

1. Cada componente declara suas portas e quais ficam interligadas em cada posição
   (`caminhos(estado)`), podendo marcar a ligação como `{dir:true}` quando só permite
   fluxo num sentido — é assim que o antirretorno deixa passar `1 → 2` mas nunca o
   inverso, e que a alternadora (OU) só permite `1 → S` e `2 → S`, nunca da saída
   de volta para as entradas.
2. Cada mangueira é uma aresta bidirecional entre duas portas de componentes diferentes.
3. A partir de toda porta marcada como `fonte` (compressor, fonte de vácuo), um
   *flood fill* pelo grafo marca todas as portas que recebem ar.
4. A válvula de simultaneidade (E) não dá para resolver só com alcançabilidade: ela
   só libera a saída quando **as duas** entradas estão pressurizadas ao mesmo tempo.
   Por isso o cálculo roda em **ponto fixo**: depois do flood fill normal, cada E que
   tiver as duas entradas atendidas vira uma nova fonte, e o flood fill roda de novo,
   repetindo até estabilizar.
5. Alguns componentes (antirretorno pilotada, escape rápido) decidem seu estado olhando
   a pressurização do **quadro anterior** — evita depender da ordem de cálculo dentro
   do mesmo quadro e é próximo do que esses componentes fazem de fato.
6. Os atuadores olham para as próprias portas: dupla ação avança quando só a porta 1
   está pressurizada e recua quando só a porta 2 está; simples ação retorna por mola;
   motor pneumático gira continuamente enquanto alimentado; atuador giratório e garra
   usam a mesma lógica da dupla ação, só que desenhada como rotação ou abertura.

É a mesma lógica de um simulador comercial, só que enxuta o suficiente para caber
em um arquivo e ser lida de cabo a rabo.

## Como usar

Abra o `index.html` no navegador. Ou publique no GitHub Pages:

```
Settings → Pages → Branch: main → / (root)
```

## Roteiro de testes

| Circuito | Montagem | Resultado esperado |
|---|---|---|
| Comando direto | compressor → 3/2 (1) · 3/2 (2) → cilindro simples (1) | avança enquanto o botão está acionado |
| Comando indireto | compressor → 5/2 (1) · 5/2 (2) → cilindro duplo (1) · 5/2 (4) → cilindro duplo (2) | a válvula guarda a posição (memória) |
| Centro fechado | compressor → 5/3 (1) | nenhuma saída pressuriza até escolher a posição − ou + |
| Antirretorno | fonte ligada na porta 2 do antirretorno | porta 1 nunca fica pressurizada; ligue na porta 1 e a 2 acende |
| Simultaneidade (E) | duas fontes, uma em cada entrada | saída só acende com as duas ligadas ao mesmo tempo |
| Alternadora (OU) | uma fonte em qualquer entrada | saída acende com qualquer uma das duas |
| Sem alimentação | cilindro ligado só na válvula | nenhuma porta fica azul |

## Próximos passos

- [ ] Editor de posição intermediária arrastável para válvulas 4/3 e 5/3 (não só três cliques fixos)
- [ ] Rede de vácuo separada da rede de pressão (hoje as duas compartilham o mesmo booleano)
- [ ] Sensores fim de curso ligados à posição real dos cilindros
- [ ] Salvar e carregar o circuito em JSON

---

Feito por: Thiagosystems
