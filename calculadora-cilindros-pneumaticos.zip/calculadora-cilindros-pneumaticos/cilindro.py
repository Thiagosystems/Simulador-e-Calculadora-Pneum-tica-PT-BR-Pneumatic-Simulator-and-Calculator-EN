"""
Dimensionamento de cilindros pneumáticos.

Entradas: pressão de trabalho, diâmetro do êmbolo, diâmetro da haste, curso.
Saídas:   força de avanço e de recuo, força útil, consumo de ar por ciclo,
          vazão necessária e tempo estimado de ciclo.

Uso como biblioteca:
    from cilindro import Cilindro
    c = Cilindro(pressao_bar=6, diam_embolo_mm=32, diam_haste_mm=12, curso_mm=200)
    print(c.relatorio())

Uso na linha de comando:
    python cilindro.py                      # modo interativo
    python cilindro.py -p 6 -d 32 -h 12 -c 200 --ciclos 30
"""

from __future__ import annotations

import argparse
import math
from dataclasses import dataclass

# --- constantes ---------------------------------------------------------
BAR_PARA_PA = 1e5          # 1 bar = 100000 Pa
PRESSAO_ATM_BAR = 1.013    # pressão atmosférica ao nível do mar
G = 9.80665                # m/s², para converter N em kgf


@dataclass
class Cilindro:
    pressao_bar: float          # pressão relativa (manométrica) na entrada
    diam_embolo_mm: float
    curso_mm: float
    diam_haste_mm: float = 0.0  # 0 = simples ação / sem desconto no recuo
    rendimento: float = 0.85    # perdas por atrito das guarnições (0,80 a 0,90)
    dupla_acao: bool = True

    # --- áreas ----------------------------------------------------------
    @property
    def area_embolo_cm2(self) -> float:
        return math.pi * (self.diam_embolo_mm / 10) ** 2 / 4

    @property
    def area_coroa_cm2(self) -> float:
        """Área do lado da haste (anular)."""
        area_haste = math.pi * (self.diam_haste_mm / 10) ** 2 / 4
        return self.area_embolo_cm2 - area_haste

    # --- forças ---------------------------------------------------------
    @property
    def forca_avanco_N(self) -> float:
        return self.pressao_bar * BAR_PARA_PA * (self.area_embolo_cm2 / 1e4)

    @property
    def forca_recuo_N(self) -> float:
        return self.pressao_bar * BAR_PARA_PA * (self.area_coroa_cm2 / 1e4)

    @property
    def forca_avanco_util_N(self) -> float:
        return self.forca_avanco_N * self.rendimento

    @property
    def forca_recuo_util_N(self) -> float:
        return self.forca_recuo_N * self.rendimento

    # --- consumo de ar ---------------------------------------------------
    @property
    def relacao_compressao(self) -> float:
        """Quantas vezes o ar é comprimido: (p_rel + p_atm) / p_atm."""
        return (self.pressao_bar + PRESSAO_ATM_BAR) / PRESSAO_ATM_BAR

    def consumo_por_ciclo_litros(self) -> float:
        """Volume de ar livre (ANR) gasto em um ciclo completo, em litros."""
        curso_dm = self.curso_mm / 100          # mm -> dm
        vol_avanco = (self.area_embolo_cm2 / 100) * curso_dm   # dm³ = litro
        vol_recuo = (self.area_coroa_cm2 / 100) * curso_dm if self.dupla_acao else 0.0
        return (vol_avanco + vol_recuo) * self.relacao_compressao

    def vazao_necessaria_l_min(self, ciclos_por_minuto: float) -> float:
        return self.consumo_por_ciclo_litros() * ciclos_por_minuto

    # --- tempo -----------------------------------------------------------
    def tempo_curso_s(self, velocidade_mm_s: float) -> float:
        if velocidade_mm_s <= 0:
            raise ValueError("A velocidade precisa ser maior que zero.")
        return self.curso_mm / velocidade_mm_s

    def tempo_ciclo_s(self, velocidade_mm_s: float) -> float:
        t = self.tempo_curso_s(velocidade_mm_s)
        return t * 2 if self.dupla_acao else t

    # --- verificação de flambagem (Euler, coluna engastada-livre) --------
    def carga_critica_flambagem_N(self, modulo_young_MPa: float = 210_000) -> float | None:
        """Carga de Euler para a haste, com fator de segurança 5 já aplicado."""
        if self.diam_haste_mm <= 0:
            return None
        inercia_mm4 = math.pi * self.diam_haste_mm ** 4 / 64
        comp_livre_mm = 2 * self.curso_mm     # engastado-livre: L_flambagem = 2L
        p_critica = (math.pi ** 2 * modulo_young_MPa * inercia_mm4) / comp_livre_mm ** 2
        return p_critica / 5

    # --- saída -----------------------------------------------------------
    def relatorio(self, ciclos_por_minuto: float = 20, velocidade_mm_s: float = 200) -> str:
        pc = self.carga_critica_flambagem_N()
        linhas = [
            "=" * 54,
            " DIMENSIONAMENTO DE CILINDRO PNEUMÁTICO",
            "=" * 54,
            f" Pressão de trabalho .......... {self.pressao_bar:8.2f} bar",
            f" Diâmetro do êmbolo ........... {self.diam_embolo_mm:8.1f} mm",
            f" Diâmetro da haste ............ {self.diam_haste_mm:8.1f} mm",
            f" Curso ........................ {self.curso_mm:8.1f} mm",
            f" Rendimento adotado ........... {self.rendimento*100:8.0f} %",
            "-" * 54,
            f" Área do êmbolo ............... {self.area_embolo_cm2:8.2f} cm²",
            f" Área da coroa ................ {self.area_coroa_cm2:8.2f} cm²",
            "-" * 54,
            f" Força teórica de avanço ...... {self.forca_avanco_N:8.1f} N"
            f"  ({self.forca_avanco_N/G:6.1f} kgf)",
            f" Força útil de avanço ......... {self.forca_avanco_util_N:8.1f} N"
            f"  ({self.forca_avanco_util_N/G:6.1f} kgf)",
            f" Força útil de recuo .......... {self.forca_recuo_util_N:8.1f} N"
            f"  ({self.forca_recuo_util_N/G:6.1f} kgf)",
            "-" * 54,
            f" Relação de compressão ........ {self.relacao_compressao:8.2f} : 1",
            f" Consumo por ciclo ............ {self.consumo_por_ciclo_litros():8.3f} L (ar livre)",
            f" Vazão a {ciclos_por_minuto:.0f} ciclos/min ......... "
            f"{self.vazao_necessaria_l_min(ciclos_por_minuto):8.1f} L/min",
            "-" * 54,
            f" Tempo de um curso ............ {self.tempo_curso_s(velocidade_mm_s):8.2f} s",
            f" Tempo de ciclo completo ...... {self.tempo_ciclo_s(velocidade_mm_s):8.2f} s",
        ]
        if pc is not None:
            linhas += [
                "-" * 54,
                f" Carga adm. p/ flambagem ...... {pc:8.1f} N (FS = 5)",
                "   " + (
                    "OK: a força de avanço está abaixo do limite."
                    if self.forca_avanco_util_N < pc
                    else "ATENÇÃO: haste subdimensionada para este curso."
                ),
            ]
        linhas.append("=" * 54)
        return "\n".join(linhas)


# --- diâmetro mínimo a partir da força desejada -------------------------
def diametro_minimo_mm(forca_desejada_N: float, pressao_bar: float,
                       rendimento: float = 0.85) -> float:
    """Menor diâmetro de êmbolo capaz de entregar a força pedida."""
    area_m2 = forca_desejada_N / (pressao_bar * BAR_PARA_PA * rendimento)
    return math.sqrt(4 * area_m2 / math.pi) * 1000


SERIE_COMERCIAL = [8, 10, 12, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200]


def proximo_comercial(diametro_mm: float) -> int:
    for d in SERIE_COMERCIAL:
        if d >= diametro_mm:
            return d
    return SERIE_COMERCIAL[-1]


# --- linha de comando ----------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="Dimensionamento de cilindros pneumáticos")
    ap.add_argument("-p", "--pressao", type=float, help="pressão de trabalho [bar]")
    ap.add_argument("-d", "--diametro", type=float, help="diâmetro do êmbolo [mm]")
    ap.add_argument("-r", "--haste", type=float, default=0, help="diâmetro da haste [mm]")
    ap.add_argument("-c", "--curso", type=float, help="curso [mm]")
    ap.add_argument("--ciclos", type=float, default=20, help="ciclos por minuto")
    ap.add_argument("--velocidade", type=float, default=200, help="velocidade do êmbolo [mm/s]")
    ap.add_argument("--simples", action="store_true", help="cilindro de simples ação")
    ap.add_argument("--forca", type=float, help="força desejada [N]: sugere o diâmetro")
    args = ap.parse_args()

    if args.forca and args.pressao:
        d = diametro_minimo_mm(args.forca, args.pressao)
        print(f"Diâmetro mínimo calculado: {d:.1f} mm")
        print(f"Diâmetro comercial sugerido: {proximo_comercial(d)} mm")
        return

    pressao = args.pressao if args.pressao else float(input("Pressão [bar]: ").replace(",", "."))
    diam = args.diametro if args.diametro else float(input("Diâmetro do êmbolo [mm]: ").replace(",", "."))
    curso = args.curso if args.curso else float(input("Curso [mm]: ").replace(",", "."))
    haste = args.haste

    c = Cilindro(
        pressao_bar=pressao,
        diam_embolo_mm=diam,
        diam_haste_mm=haste,
        curso_mm=curso,
        dupla_acao=not args.simples,
    )
    print(c.relatorio(ciclos_por_minuto=args.ciclos, velocidade_mm_s=args.velocidade))


if __name__ == "__main__":
    main()
