# Calculadora de dimensionamento de cilindros

Duas versões da mesma ferramenta: uma página web e um módulo Python.

## O que ela calcula

| Grandeza | Fórmula usada |
|---|---|
| Área do êmbolo | `A = π·D²/4` |
| Área da coroa | `A' = π·(D² − d²)/4` |
| Força de avanço | `F = p · A` |
| Força útil | `F_util = F · η` (η = 0,85 por padrão) |
| Relação de compressão | `(p_rel + 1,013) / 1,013` |
| Consumo por ciclo | `(V_avanço + V_recuo) · relação de compressão` |
| Vazão exigida | `consumo · ciclos por minuto` |
| Flambagem | Euler engastado-livre, `L_f = 2·L`, fator de segurança 5 |

## Web

Abra o `index.html`. Tudo recalcula enquanto você digita, e o desenho em corte
acompanha o diâmetro e o curso informados.

## Python

```bash
python cilindro.py -p 6 -d 32 -r 12 -c 200 --ciclos 30
```

Saída:

```
 Força útil de avanço .........    410.2 N  (  41.8 kgf)
 Consumo por ciclo ............    2.071 L (ar livre)
 Vazão a 30 ciclos/min ........     62.1 L/min
 Carga adm. p/ flambagem ......   2637.1 N (FS = 5)
   OK: a força de avanço está abaixo do limite.
```

Caminho inverso — você sabe a força e quer o diâmetro:

```bash
python cilindro.py -p 6 --forca 1500
# Diâmetro mínimo calculado: 61.2 mm
# Diâmetro comercial sugerido: 63 mm
```

Como biblioteca:

```python
from cilindro import Cilindro, diametro_minimo_mm

c = Cilindro(pressao_bar=6, diam_embolo_mm=50, diam_haste_mm=20, curso_mm=300)
print(c.forca_avanco_util_N)        # N
print(c.consumo_por_ciclo_litros()) # L de ar livre
```

## Observações de projeto

- O rendimento de 85% cobre o atrito das guarnições. Em cilindros novos e bem
  lubrificados dá para usar 0,90; em cilindros gastos, 0,80.
- O consumo é sempre em **ar livre (ANR)**, que é o número que interessa para
  escolher compressor e reservatório.
- A verificação de flambagem usa o caso mais conservador (engastado-livre).
  Se o seu cilindro tem guia ou apoio na ponta, o limite real é maior.

## Próximos passos

- [ ] Perda de carga na tubulação em função do diâmetro da mangueira
- [ ] Banco de dados com cilindros comerciais reais para comparação
- [ ] Exportar o relatório em PDF

---

Feito por: Thiagosystems
